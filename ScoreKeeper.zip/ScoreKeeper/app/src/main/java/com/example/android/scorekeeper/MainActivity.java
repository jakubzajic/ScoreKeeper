package com.example.android.scorekeeper;

import android.content.pm.ActivityInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    int scoreTeamA = 0;
    int faulTeamA = 0;
    int scoreTeamB = 0;
    int faulTeamB = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

    }

    public void addPointForTeamA(View v) {
        scoreTeamA = scoreTeamA + 1;
        displayForTeamA(scoreTeamA);
    }

    public void addFaulForTeamA(View v) {
        faulTeamA = faulTeamA + 1;
        displayForTeamAfaul(faulTeamA);
    }

    public void addPointForTeamB(View v) {
        scoreTeamB = scoreTeamB + 1;
        displayForTeamB(scoreTeamB);
    }

    public void addFaulForTeamB(View v) {
        faulTeamB = faulTeamB + 1;
        displayForTeamBfaul(faulTeamB);
    }

    /**
     * Displays the given scores for a Team.
     */
    public void displayForTeamA(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_a_score);
        scoreView.setText("Points: " + String.valueOf(score));
    }

    public void displayForTeamB(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_b_score);
        scoreView.setText("Points: " + String.valueOf(score));
    }

    public void displayForTeamAfaul(int faul) {
        TextView scoreView = (TextView) findViewById(R.id.team_a_fauls);
        scoreView.setText("Fauls: " + String.valueOf(faul));
    }

    public void displayForTeamBfaul(int faul) {
        TextView scoreView = (TextView) findViewById(R.id.team_b_fauls);
        scoreView.setText("Fauls: " + String.valueOf(faul));
    }

    public void resetAll(View v) {
        scoreTeamA = 0;
        faulTeamA = 0;
        scoreTeamB = 0;
        faulTeamB = 0;
        displayForTeamA(scoreTeamA);
        displayForTeamAfaul(faulTeamA);
        displayForTeamB(scoreTeamB);
        displayForTeamBfaul(faulTeamB);
    }
}
